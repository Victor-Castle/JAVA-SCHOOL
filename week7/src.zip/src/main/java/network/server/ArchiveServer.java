package network.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class ArchiveServer {
    private static final int PORT = 12345;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("�������������������������˿ڣ�" + PORT);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("�ͻ������ӣ�" + clientSocket.getInetAddress());
                new Thread(new ClientHandler(clientSocket)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

package GUI;

import common.AbstractUser;
import common.DataProcessing;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.Collection;

public class UserManagementJFrame extends JFrame {
    private AbstractUser currentUser;
    private JTable userTable;
    private DefaultTableModel tableModel;

    public UserManagementJFrame(AbstractUser user) {
        this.currentUser = user;
        initJFrame();
        initComponents();
        loadUserData();
    }

    private void initJFrame() {
        // ���ñ���
        this.setTitle("�û�����");
        // �����˳�����
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // ���ô��ڴ�С
        this.setSize(600, 400);
        // ���ô��ھ�����ʾ
        this.setLocationRelativeTo(null);
        // ���ô��ڿɼ�
        this.setVisible(true);
    }

    private void initComponents() {
        // ���������
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ��������ģ��
        String[] columnNames = {"�û���", "����", "��ɫ"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // ���񲻿ɱ༭
            }
        };

        // ��������
        userTable = new JTable(tableModel);
        userTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // �����������
        JScrollPane scrollPane = new JScrollPane(userTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // ������ť���
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 10));

        JButton queryButton = new JButton("��ѯ");
        JButton addButton = new JButton("����");
        JButton modifyButton = new JButton("�޸�");
        JButton deleteButton = new JButton("ɾ��");

        queryButton.setPreferredSize(new Dimension(100, 30));
        addButton.setPreferredSize(new Dimension(100, 30));
        modifyButton.setPreferredSize(new Dimension(100, 30));
        deleteButton.setPreferredSize(new Dimension(100, 30));

        buttonPanel.add(queryButton);
        buttonPanel.add(addButton);
        buttonPanel.add(modifyButton);
        buttonPanel.add(deleteButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // ��������嵽����
        this.add(mainPanel);
        // ���»��ƴ���
        this.revalidate();

        // ���Ӱ�ť�¼�
        queryButton.addActionListener(e -> showQueryDialog());
        addButton.addActionListener(e -> showAddDialog());
        modifyButton.addActionListener(e -> showModifyDialog());
        deleteButton.addActionListener(e -> showDeleteDialog());
    }

    private void loadUserData() {
        try {
            // ��ձ���
            tableModel.setRowCount(0);

            // ��ȡ�����û�
            Collection<AbstractUser> users = DataProcessing.getAllUsers();

            // �����û�������
            for (AbstractUser user : users) {
                Object[] rowData = {
                        user.getName(),
                        user.getPassword(),
                        user.getRole()
                };
                tableModel.addRow(rowData);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "�����û�����ʧ�ܣ�" + e.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void showQueryDialog() {
        // ������ѯ�Ի���
        JDialog queryDialog = new JDialog(this, "��ѯ�û�", true);
        queryDialog.setSize(300, 150);
        queryDialog.setLocationRelativeTo(this);

        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new GridLayout(2, 2, 10, 10));
        dialogPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        dialogPanel.add(new JLabel("�û�����"));
        JTextField usernameField = new JTextField();
        dialogPanel.add(usernameField);

        JButton okButton = new JButton("OK");
        JButton cancelButton = new JButton("Cancel");

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);

        dialogPanel.add(new JLabel());
        dialogPanel.add(buttonPanel);

        queryDialog.add(dialogPanel);

        okButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            if (!username.isEmpty()) {
                try {
                    AbstractUser user = DataProcessing.searchUser(username);
                    if (user != null) {
                        // ���ұ����ж�Ӧ����
                        int rowIndex = -1;
                        for (int i = 0; i < tableModel.getRowCount(); i++) {
                            if (tableModel.getValueAt(i, 0).equals(user.getName())) {
                                rowIndex = i;
                                break;
                            }
                        }

                        if (rowIndex != -1) {
                            // ѡ�и���
                            userTable.setRowSelectionInterval(rowIndex, rowIndex);
                            // ����������
                            userTable.scrollRectToVisible(userTable.getCellRect(rowIndex, 0, true));
                        } else {
                            // ���������û�У����ӵ�����ѡ��
                            Object[] rowData = {
                                    user.getName(),
                                    user.getPassword(),
                                    user.getRole()
                            };
                            tableModel.addRow(rowData);
                            rowIndex = tableModel.getRowCount() - 1;
                            userTable.setRowSelectionInterval(rowIndex, rowIndex);
                        }
                    } else {
                        JOptionPane.showMessageDialog(queryDialog, "δ�ҵ���", "��Ϣ", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(queryDialog, "��ѯʧ�ܣ�" + ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
                }
            }
            queryDialog.dispose();
        });

        cancelButton.addActionListener(e -> queryDialog.dispose());

        queryDialog.setVisible(true);
    }

    private void showAddDialog() {
        // ���������Ի���
        JDialog addDialog = new JDialog(this, "�����û�", true);
        addDialog.setSize(400, 250);
        addDialog.setLocationRelativeTo(this);

        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new GridLayout(4, 2, 10, 10));
        dialogPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        dialogPanel.add(new JLabel("�û�����"));
        JTextField usernameField = new JTextField();
        dialogPanel.add(usernameField);

        dialogPanel.add(new JLabel("���룺"));
        JPasswordField passwordField = new JPasswordField();
        dialogPanel.add(passwordField);

        dialogPanel.add(new JLabel("��ɫ��"));
        JComboBox<String> roleComboBox = new JComboBox<>(new String[]{"administrator", "operator", "browser"});
        dialogPanel.add(roleComboBox);

        JButton okButton = new JButton("ȷ��");
        JButton cancelButton = new JButton("ȡ��");

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);

        dialogPanel.add(new JLabel());
        dialogPanel.add(buttonPanel);

        addDialog.add(dialogPanel);

        okButton.addActionListener(e -> {
            String username = usernameField.getText().trim();
            String password = new String(passwordField.getPassword()).trim();
            String role = (String) roleComboBox.getSelectedItem();

            if (username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(addDialog, "�û��������벻��Ϊ��", "����", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                boolean success = DataProcessing.insertUser(username, password, role);
                if (success) {
                    JOptionPane.showMessageDialog(addDialog, "�����ɹ�", "�ɹ�", JOptionPane.INFORMATION_MESSAGE);
                    addDialog.dispose();
                    loadUserData(); // ���¼����û�����
                } else {
                    JOptionPane.showMessageDialog(addDialog, "����ʧ��", "����", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(addDialog, "����ʧ�ܣ�" + ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelButton.addActionListener(e -> addDialog.dispose());

        addDialog.setVisible(true);
    }

    private void showModifyDialog() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "��ѡ��Ҫ�޸ĵ��û�", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String username = (String) tableModel.getValueAt(selectedRow, 0);
        String password = (String) tableModel.getValueAt(selectedRow, 1);
        String role = (String) tableModel.getValueAt(selectedRow, 2);

        // �����޸ĶԻ���
        JDialog modifyDialog = new JDialog(this, "�޸��û�", true);
        modifyDialog.setSize(400, 250);
        modifyDialog.setLocationRelativeTo(this);

        JPanel dialogPanel = new JPanel();
        dialogPanel.setLayout(new GridLayout(4, 2, 10, 10));
        dialogPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        dialogPanel.add(new JLabel("�û�����"));
        JTextField usernameField = new JTextField(username);
        usernameField.setEditable(false); // �û��������޸�
        dialogPanel.add(usernameField);

        dialogPanel.add(new JLabel("���룺"));
        JPasswordField passwordField = new JPasswordField(password);
        dialogPanel.add(passwordField);

        dialogPanel.add(new JLabel("��ɫ��"));
        JComboBox<String> roleComboBox = new JComboBox<>(new String[]{"administrator", "operator", "browser"});
        roleComboBox.setSelectedItem(role);
        dialogPanel.add(roleComboBox);

        JButton okButton = new JButton("ȷ��");
        JButton cancelButton = new JButton("ȡ��");

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);

        dialogPanel.add(new JLabel());
        dialogPanel.add(buttonPanel);

        modifyDialog.add(dialogPanel);

        okButton.addActionListener(e -> {
            String newPassword = new String(passwordField.getPassword()).trim();
            String newRole = (String) roleComboBox.getSelectedItem();

            if (newPassword.isEmpty()) {
                JOptionPane.showMessageDialog(modifyDialog, "���벻��Ϊ��", "����", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                boolean success = DataProcessing.updateUser(username, newPassword, newRole);
                if (success) {
                    JOptionPane.showMessageDialog(modifyDialog, "�޸ĳɹ�", "�ɹ�", JOptionPane.INFORMATION_MESSAGE);
                    modifyDialog.dispose();
                    loadUserData(); // ���¼����û�����
                } else {
                    JOptionPane.showMessageDialog(modifyDialog, "�޸�ʧ��", "����", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(modifyDialog, "�޸�ʧ�ܣ�" + ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
            }
        });

        cancelButton.addActionListener(e -> modifyDialog.dispose());

        modifyDialog.setVisible(true);
    }

    private void showDeleteDialog() {
        int selectedRow = userTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "��ѡ��Ҫɾ�����û�", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String username = (String) tableModel.getValueAt(selectedRow, 0);

        int confirm = JOptionPane.showConfirmDialog(this, "ȷ��Ҫɾ���û� " + username + " ��", "ȷ��ɾ��", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            try {
                boolean success = DataProcessing.deleteUser(username);
                if (success) {
                    JOptionPane.showMessageDialog(this, "ɾ���ɹ�", "�ɹ�", JOptionPane.INFORMATION_MESSAGE);
                    loadUserData(); // ���¼����û�����
                } else {
                    JOptionPane.showMessageDialog(this, "ɾ��ʧ��", "����", JOptionPane.ERROR_MESSAGE);
                }
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "ɾ��ʧ�ܣ�" + ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
}
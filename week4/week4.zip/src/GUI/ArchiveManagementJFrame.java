package GUI;

import common.AbstractUser;
import common.Archive;
import common.DataProcessing;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collection;

public class ArchiveManagementJFrame extends JFrame {
    private AbstractUser user;
    private JTable archiveTable;
    private DefaultTableModel tableModel;

    public ArchiveManagementJFrame(AbstractUser user) {
        this.user = user;
        initJFrame();
        initComponents();
        loadArchiveData();
    }

    private void initJFrame() {
        // ���ñ���
        this.setTitle("��������");
        // �����˳�����
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        // ���ô��ڴ�С
        this.setSize(800, 500);
        // ���ô��ھ�����ʾ
        this.setLocationRelativeTo(null);
        // ���ô��ڿɼ�
        this.setVisible(true);
    }

    private void initComponents() {
        // ���������
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout(10, 10));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // ��������ģ��
        String[] columnNames = {"������", "������", "ʱ��", "�ļ���", "����"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // ���񲻿ɱ༭
            }
        };

        // ��������
        archiveTable = new JTable(tableModel);
        archiveTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // �����������
        JScrollPane scrollPane = new JScrollPane(archiveTable);
        mainPanel.add(scrollPane, BorderLayout.CENTER);

        // ������ť���
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        JButton queryButton = new JButton("��ѯ");
        JButton uploadButton = new JButton("�ϴ�");
        JButton downloadButton = new JButton("����");

        queryButton.setPreferredSize(new Dimension(100, 30));
        uploadButton.setPreferredSize(new Dimension(100, 30));
        downloadButton.setPreferredSize(new Dimension(100, 30));

        buttonPanel.add(queryButton);
        buttonPanel.add(uploadButton);
        buttonPanel.add(downloadButton);

        mainPanel.add(buttonPanel, BorderLayout.SOUTH);

        // ��������嵽����
        this.add(mainPanel);
        // ���»��ƴ���
        this.revalidate();

        // ���Ӱ�ť�¼�
        queryButton.addActionListener(e -> {
            String archiveId = JOptionPane.showInputDialog(this, "�����뵵���ţ�");
            if (archiveId != null && !archiveId.trim().isEmpty()) {
                try {
                    Archive archive = DataProcessing.searchArchive(archiveId);
                    if (archive != null) {
                        // ��ձ���
                        tableModel.setRowCount(0);
                        // ���Ӳ�ѯ���
                        addArchiveToTable(archive);
                    } else {
                        JOptionPane.showMessageDialog(this, "δ�ҵ��õ���", "��ѯ���", JOptionPane.INFORMATION_MESSAGE);
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(this, "��ѯʧ�ܣ�" + ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
                }
            }
        });

        uploadButton.addActionListener(e -> {
            // ����û�Ȩ��
            if (!user.getRole().equals("administrator") && !user.getRole().equals("operator")) {
                JOptionPane.showMessageDialog(this, "��û��Ȩ���ϴ�����", "Ȩ�޲���", JOptionPane.WARNING_MESSAGE);
                return;
            }

            // �����ļ�ѡ����
            JFileChooser fileChooser = new JFileChooser();
            int result = fileChooser.showOpenDialog(this);
            if (result != JFileChooser.APPROVE_OPTION) {
                return; // �û�ȡ��ѡ��
            }

            java.io.File selectedFile = fileChooser.getSelectedFile();

            // �����ϴ��Ի���
            JDialog uploadDialog = new JDialog(this, "�ϴ�����", true);
            uploadDialog.setSize(400, 300);
            uploadDialog.setLocationRelativeTo(this);

            JPanel uploadPanel = new JPanel();
            uploadPanel.setLayout(new GridLayout(5, 2, 10, 10));
            uploadPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

            uploadPanel.add(new JLabel("�����ţ�"));
            JTextField archiveIdField = new JTextField();
            uploadPanel.add(archiveIdField);

            uploadPanel.add(new JLabel("�ļ�����"));
            JTextField fileNameField = new JTextField(selectedFile.getName());
            uploadPanel.add(fileNameField);

            uploadPanel.add(new JLabel("������"));
            JTextField descriptionField = new JTextField();
            uploadPanel.add(descriptionField);

            JButton confirmButton = new JButton("ȷ���ϴ�");
            JButton cancelButton = new JButton("ȡ��");

            JPanel buttonPanel2 = new JPanel();
            buttonPanel2.add(confirmButton);
            buttonPanel2.add(cancelButton);

            uploadPanel.add(new JLabel());
            uploadPanel.add(buttonPanel2);

            uploadDialog.add(uploadPanel);

            confirmButton.addActionListener(evt -> {
                String archiveId = archiveIdField.getText().trim();
                String fileName = fileNameField.getText().trim();
                String description = descriptionField.getText().trim();

                if (archiveId.isEmpty() || fileName.isEmpty()) {
                    JOptionPane.showMessageDialog(uploadDialog, "�����ź��ļ�������Ϊ��", "����", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                try {
                    // 1. ���ļ����Ƶ�����Ŀ¼
                    java.io.File archiveDir = new java.io.File(user.archiveDir);
                    if (!archiveDir.exists()) {
                        archiveDir.mkdirs();
                    }
                    java.io.File destFile = new java.io.File(archiveDir, fileName);

                    // �����ļ�
                    java.nio.file.Files.copy(selectedFile.toPath(), destFile.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);

                    // 2. ���ӵ�����Ϣ��ϵͳ
                    boolean success = DataProcessing.insertArchive(archiveId, user.getName(), LocalDateTime.now(), description, fileName);
                    if (success) {
                        JOptionPane.showMessageDialog(uploadDialog, "�ϴ��ɹ�", "�ɹ�", JOptionPane.INFORMATION_MESSAGE);
                        uploadDialog.dispose();
                        loadArchiveData(); // ���¼��ص�������
                    } else {
                        // ������ӵ�����Ϣʧ�ܣ�ɾ���Ѹ��Ƶ��ļ�
                        destFile.delete();
                        JOptionPane.showMessageDialog(uploadDialog, "�ϴ�ʧ��", "����", JOptionPane.ERROR_MESSAGE);
                    }
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(uploadDialog, "�ϴ�ʧ�ܣ�" + ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
                } catch (java.io.IOException ex) {
                    JOptionPane.showMessageDialog(uploadDialog, "�ļ��ϴ�ʧ�ܣ�" + ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
                }
            });

            cancelButton.addActionListener(evt -> uploadDialog.dispose());

            uploadDialog.setVisible(true);
        });

        downloadButton.addActionListener(e -> {
            int selectedRow = archiveTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "��ѡ��Ҫ���صĵ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            String archiveId = (String) tableModel.getValueAt(selectedRow, 0);
            try {
                // �����û���downloadArchive����
                boolean success = user.downloadArchive(archiveId, user.downloadDir);
                if (success) {
                    JOptionPane.showMessageDialog(this, "���سɹ�", "�ɹ�", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "����ʧ��", "����", JOptionPane.ERROR_MESSAGE);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "����ʧ�ܣ�" + ex.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
            }
        });
    }

    private void loadArchiveData() {
        try {
            // ��ձ���
            tableModel.setRowCount(0);

            // ��ȡ���е���
            Collection<Archive> archives = DataProcessing.getAllArchives();

            // ���ӵ���������
            for (Archive archive : archives) {
                addArchiveToTable(archive);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "���ص���ʧ�ܣ�" + e.getMessage(), "����", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void addArchiveToTable(Archive archive) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        String timestamp = archive.getTimestamp().format(formatter);

        Object[] rowData = {
                archive.getArchiveId(),
                archive.getCreator(),
                timestamp,
                archive.getFileName(),
                archive.getDescription()
        };

        tableModel.addRow(rowData);
    }
}
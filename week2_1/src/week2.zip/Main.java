import java.sql.SQLException;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        //ѭ��������˵�
        while(true){
            PrintMenu();
            int n = 0;
            try {
                n = sc.nextInt();
            } catch (java.util.InputMismatchException e) {
                System.out.println("�����������������ѡ�");
                sc.next(); // ������뻺����
                continue;
            }
            switch (n){
                case 1:
                    login();
                    break;
                case 2:
                    try {
                        DataProcessing.disconnectFromDataBase();
                    } catch (SQLException e) {
                        System.out.println("���ݿ�Ͽ�����ʧ�ܣ�" + e.getMessage());
                    }
                    System.out.println("ϵͳ�˳���ллʹ��");
                    System.exit(0);
                    break;
                default:
                    break;
            }
        }



    }
    //��ӡ�˵�����
    public static void PrintMenu(){
        System.out.println("****��ӭ���뵵��ϵͳ****");
        System.out.println("        1.��¼        ");
        System.out.println("        2.�˳�        ");
        System.out.println("*********************");
    }

    //��¼�����ж�
    public static void login() {
        Scanner sc = new Scanner(System.in);
        try {

            DataProcessing.connectToDatabase();
            System.out.println("�������û�����");
            String name = sc.next();
            System.out.println("��������");
            String password = sc.next();
            //û�в鵽��
            if (DataProcessing.searchUser(name, password) == null) {
                System.out.println("����ʧ�ܣ�û�д���");
                return;//�������˵�
            } else {
                String role = DataProcessing.searchUser(name).getRole();
                if (role.equals("administrator")) {
                    Administrator u = (Administrator) DataProcessing.searchUser(name);
                    boolean exitFlag = false;
                    while (!exitFlag) {
                        u.showMenu();
                        String select = sc.next();
                        switch (select) {
                            case "1":
                                u.Insert();
                                break;
                            case "2":
                                u.Delete();
                                break;
                            case "3":
                                u.Update();
                                break;
                            case "4":
                                u.UserList();
                                break;
                            case "5":
                                u.Download();
                                break;
                            case "6":
                                u.FileList();
                                break;
                            case "7":
                                u.ChangePassword();
                                break;
                            case "8":
                                u.Exit();
                                exitFlag = true;
                                break;
                            default:
                                System.out.println("����ѡ����������������");
                                break;
                        }

                    }
                } else if (role.equals("operator")) {
                    Operator u = (Operator) DataProcessing.searchUser(name);
                    boolean exitFlag = false;
                    while (!exitFlag) {
                        u.showMenu();
                        String select = sc.next();
                        switch (select) {
                            case "1":
                                u.Upload();
                                break;
                            case "2":
                                u.Download();
                                break;
                            case "3":
                                u.FileList();
                                break;
                            case "4":
                                u.ChangePassword();
                                break;
                            case "5":
                                u.Exit();
                                exitFlag = true;
                                break;
                            default:
                                System.out.println("����ѡ����������������");
                                break;
                        }
                    }
                } else if (role.equals("browser")) {
                    Browser u = (Browser) DataProcessing.searchUser(name);
                    boolean exitFlag = false;
                    while (!exitFlag) {
                        u.showMenu();
                        String select = sc.next();
                        switch (select) {
                            case "1":
                                u.Download();
                                break;
                            case "2":
                                u.FileList();
                                break;
                            case "3":
                                u.ChangePassword();
                                break;
                            case "4":
                                u.Exit();
                                exitFlag = true;
                                break;
                            default:
                                System.out.println("����ѡ����������������");
                                break;
                        }
                    }
                } else {
                    System.out.println("���Ľ�ɫ������");
                    return;//�������˵�
                }

            }

        }catch (SQLException e){
            System.out.println("���ݿ����ʧ�ܣ�" + e.getMessage());
            return;
        }
    }
}
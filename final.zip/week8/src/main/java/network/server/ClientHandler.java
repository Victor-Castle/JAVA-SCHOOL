package network.server;

import common.*;
import network.Request;
import network.Response;

import java.io.*;
import java.net.Socket;
import java.sql.SQLException;
import java.time.LocalDateTime;

public class ClientHandler implements Runnable {
    private Socket socket;
    private ObjectInputStream inputStream;
    private ObjectOutputStream outputStream;
    private ServerDataProcessing dataProcessing;

    public ClientHandler(Socket socket) {
        this.socket = socket;
        this.dataProcessing = new ServerDataProcessing();
    }

    @Override
    public void run() {
        try {
            // ��ʼ����
            outputStream = new ObjectOutputStream(socket.getOutputStream());
            inputStream = new ObjectInputStream(socket.getInputStream());

            // �������ݿ�
            dataProcessing.connectToDatabase();

            // ��������
            while (true) {
                try {
                    Request request = (Request) inputStream.readObject();
                    Response response = handleRequest(request);
                    outputStream.writeObject(response);
                    outputStream.flush();
                } catch (EOFException e) {
                    // �ͻ��������ر����ӣ�����Ϊ�쳣
                    System.out.println("�ͻ������ӹرգ�" + socket.getInetAddress());
                    break;
                } catch (Exception e) {
                    // �����쳣����
                    System.err.println("���������쳣��" + e.getMessage());
                    // ���ʹ�����Ӧ
                    Response errorResponse = new Response(false, "��������ʧ�ܣ�" + e.getMessage(), null);
                    try {
                        outputStream.writeObject(errorResponse);
                        outputStream.flush();
                    } catch (Exception ex) {
                        // ����д�����
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("�ͻ��������쳣��" + e.getMessage());
        } finally {
            try {
                if (inputStream != null) inputStream.close();
                if (outputStream != null) outputStream.close();
                if (socket != null) socket.close();
                dataProcessing.disconnectFromDataBase();
            } catch (Exception e) {
                // ���Թرմ���
            }
        }
    }

    private Response handleRequest(Request request) {
        Response response;
        try {
            String threadName = Thread.currentThread().getName();
            System.out.println(threadName + ":");
            System.out.println("CLIENT_" + request.getType().name());
            if (request.getParameters() != null && request.getParameters().length > 0) {
                for (Object param : request.getParameters()) {
                    if (param != null) {
                        System.out.println(threadName + ":");
                        System.out.println(param.toString());
                    }
                }
            }

            switch (request.getType()) {
                case LOGIN:
                    String name = (String) request.getParameters()[0];
                    String password = (String) request.getParameters()[1];
                    AbstractUser user = dataProcessing.searchUser(name, password);
                    response = new Response(user != null, user != null ? "��¼�ɹ�" : "��¼ʧ��", user);
                    break;

                case GET_ALL_USERS:
                    response = new Response(true, "��ȡ�ɹ�", dataProcessing.getAllUsers());
                    break;

                case GET_ALL_ARCHIVES:
                    response = new Response(true, "��ȡ�ɹ�", dataProcessing.getAllArchives());
                    break;

                case SEARCH_USER:
                    response = new Response(true, "��ѯ�ɹ�", dataProcessing.searchUser((String) request.getParameters()[0]));
                    break;

                case SEARCH_ARCHIVE:
                    response = new Response(true, "��ѯ�ɹ�", dataProcessing.searchArchive((String) request.getParameters()[0]));
                    break;

                case INSERT_USER:
                    boolean insertUserSuccess = dataProcessing.insertUser((String) request.getParameters()[0],
                            (String) request.getParameters()[1], (String) request.getParameters()[2]);
                    response = new Response(insertUserSuccess, insertUserSuccess ? "�����ɹ�" : "����ʧ��", null);
                    break;

                case UPDATE_USER:
                    boolean updateUserSuccess = dataProcessing.updateUser((String) request.getParameters()[0],
                            (String) request.getParameters()[1], (String) request.getParameters()[2]);
                    response = new Response(updateUserSuccess, updateUserSuccess ? "���³ɹ�" : "����ʧ��", null);
                    break;

                case DELETE_USER:
                    boolean deleteUserSuccess = dataProcessing.deleteUser((String) request.getParameters()[0]);
                    response = new Response(deleteUserSuccess, deleteUserSuccess ? "ɾ���ɹ�" : "ɾ��ʧ��", null);
                    break;

                case INSERT_ARCHIVE:
                    boolean insertArchiveSuccess = dataProcessing.insertArchive((String) request.getParameters()[0],
                            (String) request.getParameters()[1], (LocalDateTime) request.getParameters()[2],
                            (String) request.getParameters()[3], (String) request.getParameters()[4]);
                    response = new Response(insertArchiveSuccess, insertArchiveSuccess ? "�����ɹ�" : "����ʧ��", null);
                    break;

                case UPDATE_ARCHIVE:
                    boolean updateArchiveSuccess = dataProcessing.updateArchive((String) request.getParameters()[0],
                            (String) request.getParameters()[1], (LocalDateTime) request.getParameters()[2],
                            (String) request.getParameters()[3], (String) request.getParameters()[4]);
                    response = new Response(updateArchiveSuccess, updateArchiveSuccess ? "���³ɹ�" : "����ʧ��", null);
                    break;

                case DELETE_ARCHIVE:
                    boolean deleteArchiveSuccess = dataProcessing.deleteArchive((String) request.getParameters()[0]);
                    response = new Response(deleteArchiveSuccess, deleteArchiveSuccess ? "ɾ���ɹ�" : "ɾ��ʧ��", null);
                    break;

                default:
                    response = new Response(false, "δ֪��������", null);
                    break;
            }
        } catch (SQLException e) {
            response = new Response(false, "���ݿ����ʧ�ܣ�" + e.getMessage(), null);
        } catch (Exception e) {
            response = new Response(false, "��������ʧ�ܣ�" + e.getMessage(), null);
        }

        // �����������Ӧ
        String threadName = Thread.currentThread().getName();
        System.out.println(threadName + ":");
        System.out.println("SERVER>>> SERVER_" + request.getType().name());
        return response;
    }
}
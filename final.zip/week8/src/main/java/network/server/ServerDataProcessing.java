package network.server;

import common.*;

import java.sql.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;

public class ServerDataProcessing {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/archive_management?useUnicode=true&characterEncoding=utf8&serverTimezone=Asia/Shanghai&useSSL=false&allowPublicKeyRetrieval=true";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "000721";
    private static final DateTimeFormatter DATE_TIME_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final int MAX_POOL_SIZE = 10;
    private static BlockingQueue<Connection> connectionPool;

    final static String ROLE_ADMINISTRATOR = "administrator";
    final static String ROLE_OPERATOR = "operator";
    final static String ROLE_BROWSER = "browser";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            initializeConnectionPool();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static void initializeConnectionPool() {
        connectionPool = new ArrayBlockingQueue<>(MAX_POOL_SIZE);
        for (int i = 0; i < MAX_POOL_SIZE; i++) {
            try {
                Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                connectionPool.offer(connection);
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        System.out.println("���ݿ����ӳس�ʼ����ɣ�������: " + connectionPool.size());
    }

    private Connection getConnection() throws SQLException {
        try {
            return connectionPool.take();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new SQLException("��ȡ���ݿ�����ʧ��", e);
        }
    }

    private void releaseConnection(Connection connection) {
        if (connection != null) {
            try {
                if (!connection.isClosed()) {
                    connectionPool.offer(connection);
                } else {
                    // �����ѹرգ����������Ӽ����
                    Connection newConnection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                    connectionPool.offer(newConnection);
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

    public void connectToDatabase() throws SQLException {
        // ���ӳ����ھ�̬��ʼ���д��������ﲻ��Ҫ�������
        System.out.println("���ݿ����ӳؾ���");
    }

    public void disconnectFromDataBase() throws SQLException {
        // ���ӳ��������̹߳�������������ر�
        System.out.println("���ݿ������ѹ黹�����ӳ�");
    }

    public AbstractUser searchUser(String name) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (name == null || name.trim().isEmpty()) {
                System.err.println("��ѯʧ�ܣ��û���Ϊ��");
                return null;
            }

            String sql = "SELECT * FROM users WHERE name = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name.trim());
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        String username = rs.getString("name");
                        String password = rs.getString("password");
                        String role = rs.getString("role");
                        return createUserByRole(username, password, role);
                    }
                }
            }
        } finally {
            releaseConnection(conn);
        }
        return null;
    }

    public AbstractUser searchUser(String name, String password) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (name == null || name.trim().isEmpty() ||
                    password == null || password.trim().isEmpty()) {
                System.err.println("��¼ʧ�ܣ��û���������Ϊ��");
                return null;
            }

            String sql = "SELECT * FROM users WHERE name = ? AND password = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name.trim());
                pstmt.setString(2, password.trim());
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        String username = rs.getString("name");
                        String userPassword = rs.getString("password");
                        String role = rs.getString("role");
                        return createUserByRole(username, userPassword, role);
                    }
                }
            }
        } finally {
            releaseConnection(conn);
        }
        return null;
    }

    public Collection<AbstractUser> getAllUsers() throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            Collection<AbstractUser> userList = new ArrayList<>();
            String sql = "SELECT * FROM users";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    String name = rs.getString("name");
                    String password = rs.getString("password");
                    String role = rs.getString("role");
                    AbstractUser user = createUserByRole(name, password, role);
                    if (user != null) {
                        userList.add(user);
                    }
                }
            }
            return userList;
        } finally {
            releaseConnection(conn);
        }
    }

    public boolean updateUser(AbstractUser user) throws SQLException {
        return updateUser(user.getName(), user.getPassword(), user.getRole());
    }

    public boolean updateUser(String name, String password, String role) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (name == null || name.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ��û�������Ϊ��");
                return false;
            }

            if (password == null || password.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ����벻��Ϊ��");
                return false;
            }

            if (role == null || role.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ���ɫ����Ϊ��");
                return false;
            }

            String trimmedName = name.trim();
            String trimmedPassword = password.trim();
            String trimmedRole = role.trim();

            if (searchUser(trimmedName) == null) {
                System.err.println("����ʧ�ܣ��û��������� - " + trimmedName);
                return false;
            }

            String sql = "UPDATE users SET password = ?, role = ? WHERE name = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, trimmedPassword);
                pstmt.setString(2, trimmedRole);
                pstmt.setString(3, trimmedName);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("�û���Ϣ���³ɹ�");
                    return true;
                }
            }
        } finally {
            releaseConnection(conn);
        }
        return false;
    }

    private AbstractUser createUserByRole(String name, String password, String role) {
        if (ROLE_ADMINISTRATOR.equalsIgnoreCase(role)) {
            return new Administrator(name, password, role);
        } else if (ROLE_OPERATOR.equalsIgnoreCase(role)) {
            return new Operator(name, password, role);
        } else if (ROLE_BROWSER.equalsIgnoreCase(role)) {
            return new Browser(name, password, role);
        } else {
            System.err.println("����ʧ�ܣ���Ч�Ľ�ɫ - " + role);
            return null;
        }
    }

    public boolean insertUser(AbstractUser user) throws SQLException {
        return insertUser(user.getName(), user.getPassword(), user.getRole());
    }

    public boolean insertUser(String name, String password, String role) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (name == null || name.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ��û�������Ϊ��");
                return false;
            }

            if (password == null || password.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ����벻��Ϊ��");
                return false;
            }

            if (role == null || role.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ���ɫ����Ϊ��");
                return false;
            }

            String trimmedName = name.trim();
            String trimmedPassword = password.trim();
            String trimmedRole = role.trim();

            if (searchUser(trimmedName) != null) {
                System.err.println("����ʧ�ܣ��û��Ѵ��� - " + trimmedName);
                return false;
            }

            String sql = "INSERT INTO users (name, password, role) VALUES (?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, trimmedName);
                pstmt.setString(2, trimmedPassword);
                pstmt.setString(3, trimmedRole);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("�û������ɹ���" + trimmedName);
                    return true;
                }
            }
        } finally {
            releaseConnection(conn);
        }
        return false;
    }

    public boolean deleteUser(String name) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (name == null || name.trim().isEmpty()) {
                System.err.println("ɾ��ʧ�ܣ��û�������Ϊ��");
                return false;
            }

            String sql = "DELETE FROM users WHERE name = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, name.trim());
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("�û�ɾ���ɹ���" + name.trim());
                    return true;
                } else {
                    System.err.println("ɾ��ʧ�ܣ��û�������");
                    return false;
                }
            }
        } finally {
            releaseConnection(conn);
        }
    }

    public Archive searchArchive(String archiveId) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (archiveId == null || archiveId.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ�������Ϊ��");
                return null;
            }

            String sql = "SELECT * FROM archives WHERE archive_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, archiveId.trim());
                try (ResultSet rs = pstmt.executeQuery()) {
                    if (rs.next()) {
                        String id = rs.getString("archive_id");
                        String creator = rs.getString("creator");
                        String timestampStr = rs.getString("timestamp");
                        LocalDateTime timestamp = LocalDateTime.parse(timestampStr, DATE_TIME_FORMATTER);
                        String description = rs.getString("description");
                        String fileName = rs.getString("file_name");
                        return new Archive(id, creator, timestamp, description, fileName);
                    }
                }
            }
        } finally {
            releaseConnection(conn);
        }
        return null;
    }

    public boolean insertArchive(String archiveId, String creator, LocalDateTime timestamp,
                                 String description, String fileName) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (archiveId == null || archiveId.trim().isEmpty() ||
                    creator == null || creator.trim().isEmpty() ||
                    fileName == null || fileName.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ������š������߻��ļ���Ϊ��");
                return false;
            }

            String trimmedArchiveId = archiveId.trim();

            if (searchArchive(trimmedArchiveId) != null) {
                System.err.println("����ʧ�ܣ��������Ѵ���");
                return false;
            }

            String sql = "INSERT INTO archives (archive_id, creator, timestamp, description, file_name) VALUES (?, ?, ?, ?, ?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, trimmedArchiveId);
                pstmt.setString(2, creator.trim());
                pstmt.setString(3, timestamp.format(DATE_TIME_FORMATTER));
                pstmt.setString(4, description != null ? description.trim() : "");
                pstmt.setString(5, fileName.trim());
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("���������ɹ���" + trimmedArchiveId);
                    return true;
                }
            }
        } finally {
            releaseConnection(conn);
        }
        return false;
    }

    public boolean insertArchive(Archive archive) throws SQLException {
        return insertArchive(archive.getArchiveId(), archive.getCreator(), archive.getTimestamp(),
                archive.getDescription(), archive.getFileName());
    }

    public Collection<Archive> getAllArchives() throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            Collection<Archive> archiveList = new ArrayList<>();
            String sql = "SELECT * FROM archives";
            try (Statement stmt = conn.createStatement();
                 ResultSet rs = stmt.executeQuery(sql)) {
                while (rs.next()) {
                    String archiveId = rs.getString("archive_id");
                    String creator = rs.getString("creator");
                    String timestampStr = rs.getString("timestamp");
                    LocalDateTime timestamp = LocalDateTime.parse(timestampStr, DATE_TIME_FORMATTER);
                    String description = rs.getString("description");
                    String fileName = rs.getString("file_name");
                    Archive archive = new Archive(archiveId, creator, timestamp, description, fileName);
                    archiveList.add(archive);
                }
            }
            return archiveList;
        } finally {
            releaseConnection(conn);
        }
    }

    public boolean deleteArchive(String archiveId) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (archiveId == null || archiveId.trim().isEmpty()) {
                System.err.println("ɾ��ʧ�ܣ������Ų���Ϊ��");
                return false;
            }

            String sql = "DELETE FROM archives WHERE archive_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, archiveId.trim());
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("����ɾ���ɹ���" + archiveId.trim());
                    return true;
                } else {
                    System.err.println("ɾ��ʧ�ܣ�����������");
                    return false;
                }
            }
        } finally {
            releaseConnection(conn);
        }
    }

    public boolean updateArchive(String archiveId, String creator, LocalDateTime timestamp,
                                 String description, String fileName) throws SQLException {
        Connection conn = null;
        try {
            conn = getConnection();
            if (archiveId == null || archiveId.trim().isEmpty() ||
                    creator == null || creator.trim().isEmpty() ||
                    fileName == null || fileName.trim().isEmpty()) {
                System.err.println("����ʧ�ܣ������š������߻��ļ���Ϊ��");
                return false;
            }

            String trimmedArchiveId = archiveId.trim();

            if (searchArchive(trimmedArchiveId) == null) {
                System.err.println("����ʧ�ܣ������Ų�����");
                return false;
            }

            String sql = "UPDATE archives SET creator = ?, timestamp = ?, description = ?, file_name = ? WHERE archive_id = ?";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setString(1, creator.trim());
                pstmt.setString(2, timestamp.format(DATE_TIME_FORMATTER));
                pstmt.setString(3, description != null ? description.trim() : "");
                pstmt.setString(4, fileName.trim());
                pstmt.setString(5, trimmedArchiveId);
                int rowsAffected = pstmt.executeUpdate();
                if (rowsAffected > 0) {
                    System.out.println("�������³ɹ���" + trimmedArchiveId);
                    return true;
                }
            }
        } finally {
            releaseConnection(conn);
        }
        return false;
    }

    public boolean updateArchive(Archive archive) throws SQLException {
        return updateArchive(archive.getArchiveId(), archive.getCreator(), archive.getTimestamp(),
                archive.getDescription(), archive.getFileName());
    }
}